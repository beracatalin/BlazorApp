﻿using System.Collections.Generic;
using System;
using System.Linq;

namespace BlazorServerApp.Data
{
    public class Angajat : IAngajat
    {
        private List<Angajați> listaangajat = new List<Angajați>
        {
            new Angajați
            {
                Id = Guid.NewGuid(),
                Name = "Test 1"

            },
            new Angajați
            {
                Id = Guid.NewGuid(),
                Name = "Test 2"

            }
        };

        public void AddAngajat(Angajați angajați)
        {
            var id = Guid.NewGuid();
            angajați.Id = id;
            listaangajat.Add(angajați);

        }

        public void DeleteAngajat(Guid id)
        {
            var angajat = GetAngajat(id);
            listaangajat.Remove(angajat);
            
        }

        public Angajați GetAngajat(Guid id)
        {
            return listaangajat.SingleOrDefault(x => x.Id == id);
        }


      
        public List<Angajați> GetAngajați()
        {
            return listaangajat;
        }

        public void UpdateAngajat(Angajați angajați)
        {
            var getAngajatVechi = GetAngajat(angajați.Id);
            getAngajatVechi.Name = angajați.Name;
        }

       
    }
}
