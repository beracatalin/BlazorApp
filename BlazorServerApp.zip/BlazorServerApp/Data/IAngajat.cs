﻿using System;
using System.Collections.Generic;

namespace BlazorServerApp.Data
{
    public interface IAngajat
    {
        List<Angajați> GetAngajați();
        
        Angajați GetAngajat(Guid id);


        void UpdateAngajat(Angajați angajați);
        void AddAngajat(Angajați angajați);
        void DeleteAngajat(Guid id);
    }
}
